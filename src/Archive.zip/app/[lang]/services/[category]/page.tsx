import { fetchSingleType, getServiceBySlug } from "@/lib/strapi";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import TopicCard from "@/components/sections/TopicCard";
import Link from "next/link";

type Props = {
  params: Promise<{ lang: string; category: string }>;
};

export default async function ServicesPage({ params }: Props) {
  const { lang, category } = await params;

  const service = await getServiceBySlug(category, lang);
  // if (!service) {
  //   return <div>Service not found</div>;
  // }

  const pageData = await fetchSingleType("support-page", {
    // Swap the flat array for an object to control deep population
    populate: {
      header: {
        populate: {
          logo: true, // ← This is the correct way for media inside a component
        },
      },
      footer: "*", // Populates all first-level fields in your footer component
    },
    locale: lang,
  });
if (!service) {
  return (
    <>
      <Nav header={pageData?.header} />

      <div className="page-layout">
        <main className="page-main">
          <div className="not-available">
            <div className="not-available-card">
              <i className="ti ti-language-off" style={{ fontSize: 36, marginBottom: 16 }}></i>
              <h1>Content not available</h1>
              <p>This service is not available in this language yet.</p>

              <Link href={`/${lang}`} className="back-link">
                ← Back to support page
              </Link>
            </div>
          </div>
        </main>
      </div>

      <Footer content={pageData?.footer?.content} />
    </>
  );
}
  if (!pageData) return <div>Failed to load data.</div>;

  return (
    <>
      <Nav header={pageData.header} />

      {/* Breadcrumb */}
      <div className="breadcrumb-bar">
        <Link href={`/${lang}`} className="breadcrumb-link">
          Help
        </Link>
        <i
          className="ti ti-chevron-right breadcrumb-sep"
          aria-hidden="true"
        ></i>
        <span className="breadcrumb-current">{service?.title}</span>
      </div>

      <div className="page-layout">
        <main className="page-main">
          {service?.service && service.service.length > 0 ? (
            <>
              <h1 className="page-heading">{service.title}</h1>

              {service.service.map((item: any, index: number) => (
                <TopicCard
                  key={item.id || index}
                  title={item.title}
                  description={item.description}
                  iconClass={item.iconClass}
                  slug={service.slug}
                  links={item.services || []}
                  defaultOpen={index === 0}
                />
              ))}
            </>
          ) : (
            <div className="no-services">
              <div className="no-services-card">
                <i
                  className="ti ti-folder-off"
                  style={{ fontSize: 32, marginBottom: 12 }}
                ></i>
                <p>No services available for this category.</p>
              </div>
            </div>
          )}
        </main>

        {/* Aside */}
        <aside className="page-aside">
          <div className="aside-card">
            <h3 className="aside-heading">Popular Articles</h3>
            <ul className="aside-links">
              <li>
                <a href="#">
                  <i className="ti ti-arrow-right" aria-hidden="true"></i>
                  Mobile Money
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="ti ti-arrow-right" aria-hidden="true"></i>
                  EFT / RTGS
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="ti ti-arrow-right" aria-hidden="true"></i>
                  International Transfers (TTs)
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="ti ti-arrow-right" aria-hidden="true"></i>
                  URA Payment
                </a>
              </li>
            </ul>
          </div>

          <div className="aside-card" style={{ marginTop: "16px" }}>
            <h3 className="aside-heading">Need more help?</h3>
            <p
              style={{
                fontSize: "13px",
                color: "var(--c-text-secondary)",
                marginBottom: "12px",
              }}
            >
              Our support team is available 24/7.
            </p>
            <a href="#" className="contact-btn">
              <i className="ti ti-headset" aria-hidden="true"></i> Contact
              Support
            </a>
          </div>
        </aside>
      </div>

      <Footer content={pageData?.footer?.content} />
    </>
  );
}
