// app/[lang]/search/page.tsx
import { fetchSingleType, searchHelpArticles } from "@/lib/strapi";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Link from "next/link";
import SearchBar from "@/components/SearchBar";

type Props = {
  params: Promise<{ lang: string }>;
  searchParams: Promise<{ q?: string }>;
};

export default async function SearchPage({ params, searchParams }: Props) {
  const { lang } = await params;
  const { q } = await searchParams;
  const query = q?.trim() || "";

  // Header & Footer
  const pageData = await fetchSingleType("support-page", {
    populate: {
      header: {
        populate: {
          logo: true,
        },
      },
      footer: "*",
    },
    locale: lang,
  });

  const results = query ? await searchHelpArticles(query, lang) : [];

  return (
    <>
      <Nav header={pageData?.header} />

      <div className="page-layout">
        <main className="page-main">
          <h1 className="page-heading">
            {query ? `Search results for “${query}”` : "Search"}
          </h1>

          {/* Keep search bar on results page too */}
          <div style={{ marginBottom: 32, maxWidth: 500 }}>
            <SearchBar
              placeholder="Search again..."
              buttonText="Search"
            />
          </div>

          {query && results.length === 0 && (
            <div className="no-services">
              <div className="no-services-card">
                <i className="ti ti-search-off" style={{ fontSize: 32, marginBottom: 12 }}></i>
                <p>No results found for “{query}”.</p>
              </div>
            </div>
          )}

          <div className="search-results">
            {results.map((item: any) => (
              <Link
                key={item.id}
                href={`/${lang}/services/card-management/${item.slug}`}
                className="search-result-item"
              >
                <h3>{item.title}</h3>
                {item.description && <p>{item.description}</p>}
              </Link>
            ))}
          </div>
        </main>
      </div>

      <Footer content={pageData?.footer?.content} />
    </>
  );
}